import java.util.Arrays;
import java.util.ArrayList;

public class FastCollinearPoints {
    private final ArrayList<Point[]> results;
    /**
     * finds all line segments containing 4 or more points
     */
    public FastCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException("null array");
        for (Point item: points) {
            if (item == null) throw new IllegalArgumentException("null item");
        }
        for (int i = 0; i < points.length; i++) {
            for (int j = i+1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0) throw new IllegalArgumentException("duplicate entry");
            }
        }
    
        Arrays.sort(points);
        Point[][] sorted = sortForAllPoints(points);

        results = new ArrayList<>();
        for (int i = 0; i < sorted.length; i++) {
            Point p = points[i];
            Point[] pList = sorted[i];
            getCollinearPoints(p, pList);
        }

        findDuplicates(results);
    }
    // sorted arrays of all points in points with each point as p
    private Point[][] sortForAllPoints(Point[] points) {
        int i = 0;
        Point[][] sorted = new Point[points.length][points.length];
        Point[] aux = points;
        for (Point p: points) {
            Arrays.sort(aux, p.slopeOrder());
            sorted[i++] = aux;
        }
        return sorted;
    }

    private void getCollinearPoints(Point p, Point[] pList) {        
        double[] aux = new double[pList.length];
        for (int i = 0; i < pList.length; i++) {
            Point q = pList[i];
            aux[i] = p.slopeTo(q);           
        }
        for (int i = 0; i < aux.length;) {
            if (i < aux.length-2 && aux[i] == aux[i+1] && aux[i] == aux[i+2]) {
                ArrayList<Point> match = new ArrayList<>();
                match.add(p);
                while (i < aux.length-1 && aux[i] == aux[i+1]) {
                    match.add(pList[i++]);
                }
                match.add(pList[i++]);
                Point[] matchArray = new Point[match.size()];
                match.toArray(matchArray);
                Arrays.sort(matchArray);
                results.add(matchArray);
            }
            else i++;
        }
    }

    private void findDuplicates(ArrayList<Point[]> r) {
        Point[][] rArray = new Point[r.size()][];
        r.toArray(rArray);
        double[] slopes = new double[r.size()];
        Point[] startpoints = new Point[r.size()];
        for (int k = 0; k < rArray.length; k++) {
            Point[] result = rArray[k];
            Point a = result[0];
            Point b = result[result.length-1];
            double slope = a.slopeTo(b);
            slopes[k] = slope;
            startpoints[k] = a;
        }
        for (int i = 0; i < rArray.length; i++) {
            for (int j = i+1; j < rArray.length; j++) {
                if (slopes[i] == slopes[j]) {
                    Point[] a = rArray[i];
                    Point[] b = rArray[j];
                    int len;
                    if (a.length <= b.length) len = a.length;
                    else len = b.length;
                    for (int m = 0; m < len; m++) {
                        if (a[m] == b[m]) {
                            if (startpoints[i].compareTo(startpoints[j]) <= 0) {
                                results.remove(b);
                                rArray[j] = a;
                            }
                            else results.remove(a);
                        }
                    }
                }
            }
        }
    }

    // number of line segments
    public int numberOfSegments() {
        return results.size();
    }
    /**
     * each maximal line segment containing 4+ points counted once
     */
    public LineSegment[] segments() {
        LineSegment[] lineSegmentResults = new LineSegment[results.size()];
        int i = 0;
        for (Point[] result: results) {
            LineSegment s = new LineSegment(result[0], result[result.length-1]);
            lineSegmentResults[i++] = s;
        }
        return lineSegmentResults;
    }
}