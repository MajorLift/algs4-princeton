// import com.sun.org.apache.xpath.internal.SourceTree;
import java.util.Arrays;
import java.util.ArrayList;

public class BruteCollinearPoints {
    private final ArrayList<Point[]> results;
    /**
     * finds all line segments containing 4 points
     * No input with 5 or more points
     * O(n^4)
     */
    public BruteCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException("null array");
        for (Point item: points) {
            if (item == null) throw new IllegalArgumentException("null item");
        }
        for (int i = 0; i < points.length; i++) {
            for (int j = i+1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0) throw new IllegalArgumentException("duplicate entry");
            }
        }

        Arrays.sort(points);
        results = new ArrayList<>();

        for (int i = 0; i < points.length; i++) {
            for (int j = i+1; j < points.length; j++) {
                for (int k = j+1; k < points.length; k++) {
                    if (points[i].slopeTo(points[j]) == points[i].slopeTo(points[k])) { 
                        for (int m = k+1; m < points.length; m++) {
                            Point[] fourPoints = new Point[] {points[i], points[j], points[k], points[m]};                  
                            if (checkCollinearity(fourPoints)) results.add(fourPoints);
                        }
                    }
                }
            }
        }
    }

    private boolean checkCollinearity(Point[] fourPoints) {
        double slopeToOne = fourPoints[0].slopeTo(fourPoints[1]);
        double slopeToTwo = fourPoints[0].slopeTo(fourPoints[2]);
        double slopeToThree = fourPoints[0].slopeTo(fourPoints[3]);

        return slopeToOne == slopeToTwo && slopeToOne == slopeToThree;
    }

    // number of line segments
    public int numberOfSegments() {
        return results.size();
    }
    /**
     * the line segments
     * should include each line segment containing 4 points exactly once.
     * same segments with different order or subsegments should not be included
     */
    public LineSegment[] segments() {
        LineSegment[] lineSegments = new LineSegment[results.size()]; 
        int i = 0;
        for (Point[] result: results) {
            LineSegment segment = new LineSegment(result[0], result[3]);
            lineSegments[i++] = segment;
        }
        return lineSegments;
    }
}